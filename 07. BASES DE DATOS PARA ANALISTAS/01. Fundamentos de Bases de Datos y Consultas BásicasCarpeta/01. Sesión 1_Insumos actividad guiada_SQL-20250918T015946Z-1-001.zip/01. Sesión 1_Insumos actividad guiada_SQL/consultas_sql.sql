-- Consulta 1: Clientes de Valparaíso
SELECT nombre, correo
FROM clientes
WHERE ciudad = 'Valparaíso';

-- Consulta 2: Ventas de junio con cliente y total
SELECT c.nombre, v.fecha, v.total
FROM ventas v
JOIN clientes c ON v.id_cliente = c.id_cliente
WHERE v.fecha BETWEEN '2024-06-01' AND '2024-06-30';

-- Consulta 3: Productos vendidos por sucursal
SELECT s.nombre_sucursal, p.nombre_producto, SUM(v.cantidad) AS unidades_vendidas
FROM ventas v
JOIN productos p ON v.id_producto = p.id_producto
JOIN sucursales s ON v.id_sucursal = s.id_sucursal
GROUP BY s.nombre_sucursal, p.nombre_producto;